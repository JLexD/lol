class TooManyRequestsError(Exception):
    pass
